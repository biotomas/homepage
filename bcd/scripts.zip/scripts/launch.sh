#!/bin/sh
echo "c launch: $1 $2"
echo "c host: `hostname`"
/home/biere/bin/run --time-limit=5000 --space-limit=7000 ./run.sh $1 "$2"
echo "c launch: done"
