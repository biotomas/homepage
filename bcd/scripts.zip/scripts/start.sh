#!/bin/sh

########################################################
# Parameter $1 contains the parameters for enc.jar     #
# Parameter $2 contains the file with the benchmarks   #
########################################################

pwd=`pwd`
arg=`echo $1 | tr -d " -="`
cat $2 | while read path name
do
  out="$pwd/expout/$name"
  qsub -e ":$out.$arg.$2.err" -o ":$out.$arg.$2.log" ./launch.sh $path "$1"
done
