#!/bin/sh
echo "c launch: $1 $2"
echo "c host: `hostname`"
file=/tmp/tmp.cnf
rm -f $file
bzcat $1 > $file
/home/biere/bin/run --time-limit=5000 --space-limit=7000 ./aig/testcnf.sh $file $2
rm -f $file
echo "c launch: done"
