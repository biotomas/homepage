#!/bin/sh

###################################
# $1 is the benchmarks file       #
# $2 contains the command for abc #
# $3 contains experiment name     #
###################################

pwd=`pwd`
cat $1 | while read path name
do
  out="$pwd/expout/$name"
  qsub -e ":$out.$3.err" -o ":$out.$3.log" ./launch.sh $path $2
done
