
######################################
# $1 contains parameters for enc.jar #
# $2 contains the command for abc    #
######################################

rm -f /tmp/tmp.aag /tmp/tmp.aig /tmp/tmp2.aig
java -Xmx4g -jar /home/tbalyo/aig/enc.jar -d=u -p=e -a -o=/tmp/tmp.aag $1
./aig/aigtoaig /tmp/tmp.aag /tmp/tmp.aig
echo BEFORE `head -n 1 /tmp/tmp.aig`
/home/biere/bin/run --time-limit=500 --space-limit=7000 /usr/bin/time -f "abctime %U" ./aig/abc -c "read /tmp/tmp.aig; $2; write /tmp/tmp2.aig" 2>&1
echo AFTER `head -n 1 /tmp/tmp2.aig`
./aig/aigtocnf /tmp/tmp2.aig /tmp/tmp.cnf
./lingeling -n /tmp/tmp.cnf
rm -f /tmp/tmp.aag /tmp/tmp.aig /tmp/tmp.cnf /tmp/tmp2.aig
