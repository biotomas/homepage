#!/bin/sh

##########################################
# $1 is the benchmark filename           #
# $2 contains the parameters for enc.jar #
##########################################

name=/tmp/`basename $1`
rm -f $name.cnf $name.rec
bzcat $1 > $name.cnf
java -Xmx4g -jar enc.jar -v=10 -o=$name.rec $name.cnf $2
rm -f $name.cnf
exec "./lingeling -n $name.rec"
rm -f $name.rec
echo "c launch: done"
