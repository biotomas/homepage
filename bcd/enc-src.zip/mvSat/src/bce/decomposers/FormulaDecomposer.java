package bce.decomposers;

import satLifter.sat.DimacsParser.BasicFormula;

public interface FormulaDecomposer {
	
	public void decomposeFormula(BasicFormula input, BasicFormula largeBlocked, BasicFormula rest);

}
