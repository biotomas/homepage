package satLifter;

import java.util.List;

import satLifter.multiSat.MultiValuedCNF;
import satLifter.sat.DimacsParser;
import satLifter.sat.DimacsParser.BasicFormula;
import satLifter.translation.SatToMultiValuedSat;
import satLifter.translation.covering.CliqueCoverGenerator;
import satLifter.translation.covering.GreedyLeftistCliqueCoverGenerator;
import satLifter.translation.covering.NaiveRandomizedCliqueCoverGenerator;
import satLifter.translation.mutex.BasicMutexFinder;
import satLifter.translation.mutex.ImprovedMutexFinder;
import satLifter.translation.mutex.MutexFinder;
import satLifter.translation.mutex.MutexPair;

public class Main {
    
    private static enum Method {
        basic_naive,
        basic_greedy,
        improved_naive,
        improved_greedy
    }

    public static void main(String[] args) {
        Stopwatch totalTime = new Stopwatch();
        
        if (args.length < 1) {
            System.out.println("Usage: lifter.jar <filename.cnf> [result] [-m <method>]");
            System.out.println("Methods: basic-naive     = basic mutex finder + naive cover");
            System.out.println("Methods: basic-greedy    = basic mutex finder + greedy cover");
            System.out.println("Methods: improved-naive  = improv. mutex finder + naive cover");
            System.out.println("Methods: improved-greedy = improv. mutex finder + greedy cover");
            return;
        }
        
        String filename = args[0];
        BasicFormula formula = DimacsParser.parseFromFile(filename);
        
        // the default method
        Method method = Method.basic_naive;
        
        if (args.length > 1 && args[1].equals("-m")) {
            method = Method.valueOf(args[2]);
        }
        
        // finding mutexes
        Stopwatch mutexTime = new Stopwatch();
        List<MutexPair> mutexes = null;
        
        switch (method) {
        case basic_naive:
        case basic_greedy:
            MutexFinder mutexFinder = new BasicMutexFinder();
            mutexes = mutexFinder.findMutexPairs(formula);
            break;
        case improved_greedy:
        case improved_naive:
            mutexFinder = new ImprovedMutexFinder();
            mutexes = mutexFinder.findMutexPairs(formula);
            break;
        }
        mutexTime.pause();
        
        // finding a clique cover
        Stopwatch coverTime = new Stopwatch();
        List<List<Integer>> cover = null;
        
        switch(method) {
        case basic_naive:
        case improved_naive:
            CliqueCoverGenerator generator = new NaiveRandomizedCliqueCoverGenerator(2013, formula.variablesCount, mutexes);
            cover = generator.generateCliqueCover();
            break;
        case basic_greedy:
        case improved_greedy:
            generator = new GreedyLeftistCliqueCoverGenerator(2013, formula.variablesCount, mutexes);
            cover = generator.generateCliqueCover();
            break;
        }
        coverTime.pause();
        
        // translating the formula
        Stopwatch translationTime = new Stopwatch();
        SatToMultiValuedSat translator = new SatToMultiValuedSat();
        MultiValuedCNF mvCnf = translator.translate(formula, cover);
        translationTime.pause();
        
        // print the formula
        mvCnf.printNoGoodFormat(System.out);
        
        // print the statistics
        System.err.println("head;input;method;vars;clauses;newVars;newClauses;totalTime;mutexTime;coverTime;translateTime");
        System.err.println(String.format("data;%s;%s;%d;%d;%d;%d;%s;%s;%s;%s", filename, method.toString(), 
                formula.variablesCount, formula.clauses.size(), mvCnf.variablesCount, mvCnf.formula.size(),
                totalTime.elapsedFormatedSeconds(), mutexTime.elapsedFormatedSeconds(), coverTime.elapsedFormatedSeconds(), translationTime.elapsedFormatedSeconds()));
    }

}
