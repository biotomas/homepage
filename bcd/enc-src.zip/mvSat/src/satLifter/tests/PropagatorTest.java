package satLifter.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import junit.framework.TestCase;
import satLifter.sat.DimacsParser.BasicFormula;
import satLifter.sat.Propagator;

public class PropagatorTest extends TestCase {
    
    public void testPropagatorBasic() {
        Propagator p = new Propagator(10);
        
        p.addClause(new int[]{1, 2, 3});
        p.addClause(new int[]{-2, 3});
        p.addClause(new int[]{-3, 4});
        p.addClause(new int[]{-2, -4, 5});
        p.addClause(new int[]{-1, -5, 9});

        assertEquals(null, p.propagate(2,-5));
        p.restartPropagator();
        assertTrue(p.propagate(2).containsAll(Arrays.asList(2,3,4,5)));
    }
    
    public void testPropagatorOnRandom() {
        RandomFormulaGenerator fgen = new RandomFormulaGenerator(2013);
        Random rnd = new Random(2012);
        
        for (int i = 10; i < 100; i++) {
            int vars = i * 50;
            BasicFormula f = fgen.getRandomSat(vars, vars, 5*vars);
            Propagator p = new Propagator(f.variablesCount);
            for (int[] cl : f.clauses) {
                p.addClause(cl);
            }
            int lit1 = rnd.nextInt(vars) + 1;
            int lit2 = rnd.nextInt(vars) + 1;
            List<Integer> result1 = trivialPropagate(f, lit1, lit2);
            List<Integer> result2 = p.propagate(lit1, lit2);
            
            if (result1 == null || result2 == null) {
                assertNull(result1);
                assertNull(result2);
            } else {
                assertTrue(result1.containsAll(result2));
                assertTrue(result2.containsAll(result1));
            }
        }
    }
    
    
    private ArrayList<Integer> trivialPropagate(BasicFormula f, int lit1, int lit2) {
        int[] values = new int[f.variablesCount+1];
        ArrayList<Integer> assignments = new ArrayList<Integer>();
        Arrays.fill(values, 0);
        values[Math.abs(lit1)] = lit1;
        values[Math.abs(lit2)] = lit2;
        assignments.add(lit1);
        assignments.add(lit2);
        
        while (true) {
            boolean newAssignment = false;
            for (int[] cl : f.clauses) {
                int freeLits = 0;
                int unit = 0;
                boolean sat = false;
                for (int lit : cl) {
                    if (values[Math.abs(lit)] == lit) {
                        sat = true;
                        break;
                    }
                    if (values[Math.abs(lit)] == 0) {
                        unit = lit;
                        freeLits++;
                    }
                }
                if (!sat && freeLits == 0) {
                    // conflict
                    return null;
                }
                if (!sat && freeLits == 1) {
                    // propagation
                    assignments.add(unit);
                    values[Math.abs(unit)] = unit;
                    newAssignment = true;
                }
            }
            if (newAssignment == false) {
                break;
            }
        }
        
        return assignments;
    }

}
