package satLifter.translation.covering;

import java.util.List;

public interface CliqueCoverGenerator {
    
    public List<List<Integer>> generateCliqueCover();

}
