package satSolver.localSearch.selectors;

import satSolver.localSearch.BaseWalkSAT.LocalSearchMetadata;

public class FlipFirst implements LocalSearchSelector {
    
	@Override
	public void prepareForFlipping(LocalSearchMetadata lsData) {
	}

	@Override
	public int selectLiteralToFlip(int[] candidates) {
		return candidates[0];
	}

}
