package satSolver.localSearch.selectors;

import java.util.Random;

import satSolver.localSearch.BaseWalkSAT.LocalSearchMetadata;

public class RandomWalk implements LocalSearchSelector {

	private Random random;

	@Override
	public void prepareForFlipping(LocalSearchMetadata lsData) {
		this.random = lsData.random;
	}

	@Override
	public int selectLiteralToFlip(int[] candidates) {
		return candidates[random.nextInt(candidates.length)];
	}

}
