package satSolver.tests;

import java.io.File;
import java.util.Arrays;

import junit.framework.TestCase;
import satLifter.Stopwatch;
import satLifter.sat.DimacsParser;
import satLifter.sat.DimacsParser.BasicFormula;
import satLifter.tests.RandomFormulaGenerator;
import satSolver.LocalSearchSatSolver;
import satSolver.Sat4JSolver;
import satSolver.SatSolver;
import satSolver.localSearch.BaseWalkSAT;
import satSolver.localSearch.LocalSearchMain;
import satSolver.localSearch.selectors.ProbSat;
import satSolver.localSearch.selectors.WalkSat;

public class Random3SatLocal extends TestCase {
	
	public void testOnFiles() {
		String path = "/home/tbalyo/workspace/bcd/data/myrandom/out";
        File benchDir = new File(path);
        File[] files = benchDir.listFiles();
        Arrays.sort(files);
        // with stack:      queue	
        // probsat 19.406	3.978
        // walksat 4.339	4.995
        // sparrow 28.248	19.75
        // bseeker 150.43	0.896
        // gatling 107.00	7.394
        // revolve 10.867	2.350
		LocalSearchSatSolver local = new BaseWalkSAT(new ProbSat(), 2013);
		local.setTimeout(5000000000l); //5s
		Stopwatch totalTime = new Stopwatch();
		totalTime.pause();
		int problemNr = 1;
		int timeouts = 0;
		float totalFps = 0;
		long totalFlips = 0;
        for (File file : files) {
        	System.out.print(String.format("(%3d/%d) ", problemNr++, files.length));
        	BasicFormula f = DimacsParser.parseFromFile(file.getAbsolutePath());
        	//BasicFormula f = DimacsParser.parseFromFile("/home/tbalyo/big3sat.cnf");
			Stopwatch timer = new Stopwatch();
			totalTime.unpause();
			Boolean res = local.isSatisfiable(f);
			totalTime.pause();
			float fps = local.getFlipsCount()/timer.elapsedSecondsFloat();
			totalFps += fps;
			totalFlips += local.getFlipsCount();
			System.out.print(timer.elapsedFormatedSeconds());
			System.out.print(String.format(" restarts: %3d flips: %12d fps: %.3f", local.getRestartsCount(), 
					local.getFlipsCount(), fps));
			if (res == null) {
				System.out.print(" TIMEOUT");
				timeouts++;
			}
			System.out.println();
			if (res != null && !LocalSearchMain.solutionValid(f, local.getModel())) {
				System.err.println("Invalid Solution");
				return;
			}
        }
		System.out.println(String.format("time: %s timeouts %d (of %d) avg. fps %f flips %d", 
				totalTime.elapsedFormatedSeconds(), timeouts, files.length, totalFps/files.length, totalFlips));
	}
	
	public void testLocalSearchPerformance() {
		int vars = 200;
		int clauses = 860;
		int tests = 100;
		
		RandomFormulaGenerator rfg = new RandomFormulaGenerator(5000);
		Sat4JSolver sat4j = new Sat4JSolver();
		// Sparrow 52.704
		// WalkSat 3.351
		// ProbSat 11.632
		SatSolver local = new BaseWalkSAT(new WalkSat(), 2013);
		Stopwatch totalTime = new Stopwatch();
		totalTime.pause();
		while (tests > 0) {
			BasicFormula f = rfg.getRandomSat(vars, 0, clauses);
			if (sat4j.isSatisfiable(f)) {
				tests--;
				Stopwatch timer = new Stopwatch();
				totalTime.unpause();
				local.isSatisfiable(f);
				totalTime.pause();
				System.out.println(timer.elapsedFormatedSeconds());
				if (!LocalSearchMain.solutionValid(f, local.getModel())) {
					System.err.println("Invalid Solution");
					return;
				}
			}
		}
		System.out.println("Total time: " + totalTime.elapsedFormatedSeconds());
	}

}
