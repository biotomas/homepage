ulimit -t 600
for d in ../Problems/sas/*
do
file=$d/`ls $d | head -n 1`
echo $file
java -jar fltran.jar $file isase 3 -s >> sase.log
java -jar fltran.jar $file disertDirect 3 -s >> direct.log
java -jar fltran.jar $file exist 3 -s >> exist.log
java -jar fltran.jar $file compactReinforced 3 -s >> reinforced.log
done
