ulimit -t 600

for l in ../Problems/pddl/*.list
do
read d p < $l
#echo $d "..." $p
rm -f tmp.003.cnf
./mtrans.sh optprobs/$d optprobs/$p 1 3 tmp
echo -n $p "rint-all" >> rint1opt.log
java -jar flan.jar tmp.003.cnf >> rint1opt.log
rm -f tmp.003.cnf
./mtrans.sh optprobs/$d optprobs/$p 2 3 tmp
echo -n $p "rint-ex" >> rint2opt.log
java -jar flan.jar tmp.003.cnf >> rint2opt.log
rm -f tmp.003.cnf
done
