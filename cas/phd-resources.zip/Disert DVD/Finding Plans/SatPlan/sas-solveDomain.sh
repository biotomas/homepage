#param: domain method
tlimit=1800
ulimit -t $tlimit

for p in optsas/$1/*.sas
do
    m=$2
    filename=res-$1-$m.txt
    java -jar flsat.jar $p $m $tlimit &>> $filename
    echo "end" >> $filename
done