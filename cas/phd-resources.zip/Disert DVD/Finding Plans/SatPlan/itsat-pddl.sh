#!/bin/bash
#parameters: domain.pddl, problem.pddl, semantics
#returns:    makespan of the plan
timelimit=1800

#echo "params:" $1 $2 $3

makespan=1
sat=20
cnfinput=""
ulimit -t $timelimit
totalSatTime=0
while [ $sat -eq 20 ]
do
	./mtrans.sh $1 $2 $3 $makespan "cnffile" &> /dev/null
	for f in cnffile*; do cnfinput=$f; done
	#echo "input is" $cnfinput
	/usr/bin/time -f "%e" ./lingeling -q $cnfinput > /dev/null 2> timefile
	sat=$?
	rm $cnfinput
	stime=`tail -n 1 timefile`
	totalSatTime=`echo $stime + $totalSatTime | bc`
	#echo "solver time" $stime "total solver time" $totalSatTime
	
	timeout=`echo "$totalSatTime>=$timelimit" | bc`
	if [ $timeout -eq 1 ]
	then
	    echo "sat limit exceeded"
	    break
	fi
	
	makespan=$[makespan+1]
done
if [ $sat -eq 10 ]
then
    echo "SOLVED" $2 "makespan" $[makespan-1] "sat-time" $totalSatTime 1>&2
else
    echo "FAILED" $2
fi
