#!/bin/bash

#params listfile method (1 or 2)
method=$2
while read domain problem
do
/usr/bin/time -f "TIME-FOR $problem %e" ./itsat-pddl.sh $domain $problem $method &>> res-rint-$method-`basename $1`.txt
done < $1
cp res-rint-$method-`basename $1`.txt ~/dis/rintres/