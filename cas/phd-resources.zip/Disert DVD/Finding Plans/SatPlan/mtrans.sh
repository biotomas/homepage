#params: domain, problem, semantic, makespan, outputname
./m $1 $2 -P $3 -O -F $4 -T $4 -b $5
