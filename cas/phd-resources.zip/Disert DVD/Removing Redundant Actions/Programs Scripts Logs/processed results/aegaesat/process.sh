doms="barman elevators floortile nomystery openstacks parcprinter parking pegsol scanalyzer sokoban tidybot transport visitall woodworking"
for d in $doms
do
	f=aegaesat-ff.log.res
	ffprobs=`grep $d $f | wc -l | cut -d " " -f 1`
	ffae=`grep $d $f | grep "pfae" | wc -l | cut -d " " -f 1`
	ffgae=`grep $d $f | grep "pfgae" | wc -l | cut -d " " -f 1`

	f=aegaesat-fd.log.res
	fdprobs=`grep $d $f | wc -l | cut -d " " -f 1`
	fdae=`grep $d $f | grep "pfae" | wc -l | cut -d " " -f 1`
	fdgae=`grep $d $f | grep "pfgae" | wc -l | cut -d " " -f 1`

	f=aegaesat-mp.log.res
	mpprobs=`grep $d $f | wc -l | cut -d " " -f 1`
	mpae=`grep $d $f | grep "pfae" | wc -l | cut -d " " -f 1`
	mpgae=`grep $d $f | grep "pfgae" | wc -l | cut -d " " -f 1`


	echo "$d&$ffprobs&$ffae&$ffgae&$fdprobs&$fdae&$fdgae&$mpprobs&$mpae&$mpgae \\\\"
done
