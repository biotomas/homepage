rm -f wmsat.wcnf
java -jar flred.jar wpmax $1 $2 wmsat.wcnf

rm -f wtmpfile
/usr/bin/time -f "cpuTime %e" ./toysat wmsat.wcnf &> wtmpfile
stime=`grep "cpuTime" wtmpfile | tr -d " cpuTime"`

echo  "wpmaxsat-res;"$stime";"
rm -f tmpfile
java -jar flred.jar eval $1 $2 wtmpfile > tmpfile
#cat tmpfile
echo "data;wmax;"`grep "data;eval" tmpfile | cut -d ";" -f 3,4,5,6,7`";"$stime
