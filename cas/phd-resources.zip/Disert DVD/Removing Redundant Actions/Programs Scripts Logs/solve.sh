rm -f msat.wcnf
java -jar flred.jar pmax $1 $2 msat.wcnf

rm -f wtmpfile
./qmaxsat0.4comp_static msat.wcnf &> wtmpfile

stime=`grep "CPU" wtmpfile | tr -d " s:cCPUtime"`
ans=`grep "Answer" wtmpfile | cut -d " " -f 4`
echo "maxsat-res;"$2";"$stime";"$ans

rm -f tmpfile
java -jar flred.jar eval $1 $2 wtmpfile > tmpfile
#cat tmpfile
echo "data;max;"`grep "data;eval" tmpfile | cut -d ";" -f 3,4,5,6,7`";"$stime
