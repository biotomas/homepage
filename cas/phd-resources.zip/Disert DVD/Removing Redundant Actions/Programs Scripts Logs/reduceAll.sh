ulimit -t 600
for f in ../keps14/problems/*/*.mpp
do
    sas=`echo $f | sed 's/mpp$/sas/g'`
    echo $sas $f
    #./solve.sh $sas $f &>> reduce-mp.log
    #./wsolve.sh $sas $f &>> wreduce-mp.log
    #java -jar flred.jar ae $sas $f &>> ae-mp.log
    #java -jar flred.jar gae $sas $f &>> gae-mp.log
    #java -jar flred.jar sat $sas $f &>> sat-mp.log
    java -jar flred.jar aegaesat $sas $f &>> aegaesat-mp.log
done
for f in ../keps14/problems/*/*.ffp
do
    sas=`echo $f | sed 's/ffp$/sas/g'`
    echo $sas $f
    #./solve.sh $sas $f &>> reduce-ff.log
    #./wsolve.sh $sas $f &>> wreduce-ff.log
    #java -jar flred.jar ae $sas $f &>> ae-ff.log
    #java -jar flred.jar gae $sas $f &>> gae-ff.log
    #java -jar flred.jar sat $sas $f &>> sat-ff.log
    java -jar flred.jar aegaesat $sas $f &>> aegaesat-ff.log
done
for f in ../keps14/problems/*/*.fix
do
    sas=`echo $f | sed 's/.fdp.fix$//g'`
    echo $sas $f
    #./solve.sh $sas $f &>> reduce-fd.log
    #./wsolve.sh $sas $f &>> wreduce-fd.log
    #java -jar flred.jar ae $sas $f &>> ae-fd.log
    #java -jar flred.jar gae $sas $f &>> gae-fd.log
    #java -jar flred.jar sat $sas $f &>> sat-fd.log
    java -jar flred.jar aegaesat $sas $f &>> aegaesat-fd.log
done
