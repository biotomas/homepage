Contents of this DVD
====================
thesis.pdf - the text of the doctoral dissertation thesis.

freelunch.zip - java source code (eclipse project) of the freelunch planning library containing all the algorithms described in the thesis.

Finding Plans - data, software, and linux executables required to replicate the experiments of the 3rd chapter of the thesis including the results of these experiments.

Removing Redundant Actions -data, software, and linux executables required to replicate the experiments of the 4th chapter of the thesis including the results of these experiments.


For more information please contact the author:
Tomas Balyo, email: biotomas@gmail.com
