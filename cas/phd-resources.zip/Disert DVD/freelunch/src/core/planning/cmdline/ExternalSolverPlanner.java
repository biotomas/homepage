package core.planning.cmdline;

import java.io.IOException;
import java.util.Arrays;

import core.planning.NonexistentPlanException;
import core.planning.TimeoutException;
import core.planning.cmdline.Translator.TranslationMethod;
import core.planning.model.SasParallelPlan;
import core.planning.model.SasProblem;
import core.planning.sase.optimizer.PlanVerifier;
import core.planning.sase.sasToSat.SasParser;
import core.planning.sase.sasToSat.iterative.IterativeSatBasedSolver;
import core.planning.sase.sasToSat.translator.ActionOrientedTranslator;
import core.planning.sase.sasToSat.translator.BinaryReinforcedSaseTranslator;
import core.planning.sase.sasToSat.translator.CompactDirect;
import core.planning.sase.sasToSat.translator.CompactReinforcedSaseTranslator;
import core.planning.sase.sasToSat.translator.DirectDoubleLinkedTranslator;
import core.planning.sase.sasToSat.translator.DirectExistStepTranslator;
import core.planning.sase.sasToSat.translator.DirectTranslator;
import core.planning.sase.sasToSat.translator.DisertDirectTranslator;
import core.planning.sase.sasToSat.translator.MiniBinTranslator;
import core.planning.sase.sasToSat.translator.ReinforcedSaseTranslator;
import core.planning.sase.sasToSat.translator.SasToSatTranslator;
import core.planning.sase.sasToSat.translator.SaseTranslator;
import core.planning.sase.sasToSat.translator.SaseTranslatorSettings;
import core.planning.sase.sasToSat.translator.SelectiveTranslator;
import core.satSolving.ExternalSatSolver;
import core.utilities.ArrayUtils;
import core.utilities.Stopwatch;

public class ExternalSolverPlanner {
    
    public static void main(String[] args) {
        if (args.length < 3) {
            System.out.println("USAGE: java -jar fl.jar <problem.sas> <method> <sat-timelimit> [-p print plan] [-r N ranking type]");
            System.out.println("Methods: " + Arrays.toString(TranslationMethod.values()));
            return;
        }
        String problemName = args[0];
        TranslationMethod method = TranslationMethod.valueOf(args[1]);
        int timeLimit = Integer.parseInt(args[2]);
        boolean printPlan = false;
        if (ArrayUtils.find(args, "-p") >= 0) {
            printPlan = true;
        }
        int rid = ArrayUtils.find(args, "-r");
        // default ranking is 5
        int ranking = 5;
        if (rid >= 0) {
            ranking = Integer.parseInt(args[rid+1]);
        }

        SasParser parser = new SasParser();
        SasProblem problem = null;
        
        System.out.print("Running ExternalSolverPlanner with params: " + Arrays.toString(args) + " ");

        try {
            problem = parser.parse(problemName);
            problem.setActionIDs();

            SasToSatTranslator translator = null;
            switch (method) {
            case isase:
                translator = new SaseTranslator(problem);
                break;
            case direct:
                translator = new DirectTranslator(problem);
                break;
            case sase:
                SaseTranslatorSettings settings = new SaseTranslatorSettings();
                settings.setUseOriginalGoalEncoding(true);
                settings.setUseOriginalInitialStateEncoding(true);
                translator = new SaseTranslator(problem, settings);
                break;
            case action:
                translator = new ActionOrientedTranslator(problem);
                break;
            case linear:
                translator = new DirectDoubleLinkedTranslator(problem);
                break;
            case exist:
                translator = new DirectExistStepTranslator(problem, ranking);
                break;
            case reinforced:
                translator = new ReinforcedSaseTranslator(problem);
                break;
            case disertDirect:
                translator = new DisertDirectTranslator(problem);
                break;
            case compactDirect:
                translator = new CompactDirect(problem);
                break;
            case compactReinforced:
                translator = new CompactReinforcedSaseTranslator(problem);
                break;
            case binaryReinforced:
                translator = new BinaryReinforcedSaseTranslator(problem);
                break;
            case miniBin:
                translator = new MiniBinTranslator(problem);
                break;
            case selective:
                translator = new SelectiveTranslator(problem);
                break;
            }
            
            Stopwatch solveTime = new Stopwatch();
            IterativeSatBasedSolver solver = new IterativeSatBasedSolver(new ExternalSatSolver(), translator);
            solver.getSettings().setSatLimit(timeLimit);
            if (printPlan) {
                solver.getSettings().setVerbose(true);
            }
            SasParallelPlan plan = solver.solve();
            
            System.out.println(String.format("SOLVED in %s with %d steps sat-time %.2f", solveTime.elapsedFormatedSeconds(), plan.getPlanLength(),
                    ((float)solver.getStats().satTime)/1000f));
            
            if (printPlan) {
                System.out.println(plan);
            }
            
            PlanVerifier verifier = new PlanVerifier();
            boolean valid = verifier.verifyPlan(problem, plan);
            if (!valid) {
                System.out.println("!!!!!! INVALID PLAN !!!!!!");
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        } catch (TimeoutException e) {
            System.out.println("TIMEOUT");
        } catch (NonexistentPlanException e) {
            System.out.println("Plan does not exist");
        }

    }

}
