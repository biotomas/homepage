/*******************************************************************************
 * Copyright (c) 2013 Tomas Balyo and Vojtech Bardiovsky
 * 
 * This file is part of freeLunch
 * 
 * freeLunch is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation, either version 3 of the License, 
 * or (at your option) any later version.
 * 
 * freeLunch is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty 
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with freeLunch.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/
package core.planning.cmdline;

import java.io.IOException;

import core.planning.NonexistentPlanException;
import core.planning.Solver;
import core.planning.TimeoutException;
import core.planning.forwardSearch.MemoryEfficientForwardSearchSolver;
import core.planning.model.SasParallelPlan;
import core.planning.model.SasProblem;
import core.planning.sase.optimizer.PlanVerifier;
import core.planning.sase.sasToSat.SasParser;
import core.utilities.Stopwatch;


public class BFSSolver {

    /**
     * @param args
     */
    public static void main(String[] args) {
        
        Stopwatch watch = new Stopwatch();
        String message = "Solved";
        int planSize = 0;
        if (args.length < 1) {
            System.out.println("USAGE: java -jar bfs.jar <problem.sas>  [plan-file]");
            return;
        }
        String filename = args[0];
        String planFile = args.length > 1 ? args[1] : null;
        try {
            SasParser parser = new SasParser();
            SasProblem problem = parser.parse(filename);
            Solver solver = new MemoryEfficientForwardSearchSolver(problem);

            SasParallelPlan plan = solver.solve();
            planSize = plan.getPlanLength();
            PlanVerifier verifier = new PlanVerifier();
            boolean valid = verifier.verifyPlan(problem, plan);
            
            if (!valid) {
                System.out.println(filename + ";Invalid plan found");
                return;
            }

            if (planFile != null) {
                plan.saveToFileIpcFormat(planFile);
            }
            
        } catch (IOException e) {
            message = "File cannot be opened";
        } catch (TimeoutException e) {
            message = "Timeout Occurred";
        } catch (NonexistentPlanException e) {
            message = "Plan does not exist";
        } catch (OutOfMemoryError e) {
            message = "Out of memory";
        } catch (Throwable e) {
            System.out.println(filename + ";Unexpected error");
            e.printStackTrace(System.out);
            return;
        }
        System.out.println("header;file;result;planSize;time");
        System.out.println(String.format("data;%s;%s;%d;%s", filename, message, planSize, watch.elapsedFormatedSeconds()));
    }

}
