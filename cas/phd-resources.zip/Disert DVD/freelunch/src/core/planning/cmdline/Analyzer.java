package core.planning.cmdline;

import java.io.IOException;

import core.planning.SasProblemAnalyzer;
import core.planning.SasProblemAnalyzer.SasProblemProperties;
import core.planning.model.SasProblem;
import core.planning.sase.sasToSat.SasParser;
import core.satModelling.modelObjects.BasicSatFormula;
import core.satSolving.FormulaAnalyzer;
import core.utilities.Logger;

public class Analyzer {

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("USAGE: java -jar fl.jar formula.cnf OR problem.sas");
            return;
        }
        String filename = args[0];
        if (filename.contains("cnf")) {
            BasicSatFormula f = BasicSatFormula.parseFromFile(filename);
            System.out.println(filename + ";" + FormulaAnalyzer.analyzeFormula(f).csv());
        } else {
            SasProblemAnalyzer spa = new SasProblemAnalyzer();
            SasParser parser = new SasParser();
            SasProblem prob;
            try {
                prob = parser.parse(filename);
                Logger.print(0, "start");
                SasProblemProperties spp = spa.analyzeSasProblem(prob);
                System.out.println(spp);
                Logger.print(0, "done");
            } catch (IOException e) {
                System.out.println("sas file cannot be opened");
            }
        }
    }
}
