/*******************************************************************************
 * Copyright (c) 2013 Tomas Balyo and Vojtech Bardiovsky
 * 
 * This file is part of freeLunch
 * 
 * freeLunch is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation, either version 3 of the License, 
 * or (at your option) any later version.
 * 
 * freeLunch is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty 
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with freeLunch.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/
package core.planning.cmdline;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import core.planning.model.SasAction;
import core.planning.model.SasProblem;
import core.planning.sase.preprocessing.DoubleActionCodec;
import core.planning.sase.sasToMultiSat.MultiValuedCNF;
import core.planning.sase.sasToMultiSat.SasToMVSat;
import core.planning.sase.sasToSat.SasParser;
import core.planning.sase.sasToSat.translator.ActionOrientedTranslator;
import core.planning.sase.sasToSat.translator.BinaryReinforcedSaseTranslator;
import core.planning.sase.sasToSat.translator.CompactDirect;
import core.planning.sase.sasToSat.translator.CompactReinforcedSaseTranslator;
import core.planning.sase.sasToSat.translator.DirectDoubleLinkedTranslator;
import core.planning.sase.sasToSat.translator.DirectExistStepTranslator;
import core.planning.sase.sasToSat.translator.DirectTranslator;
import core.planning.sase.sasToSat.translator.DisertDirectTranslator;
import core.planning.sase.sasToSat.translator.MiniBinTranslator;
import core.planning.sase.sasToSat.translator.ReinforcedSaseTranslator;
import core.planning.sase.sasToSat.translator.SasToSatTranslator;
import core.planning.sase.sasToSat.translator.SaseTranslator;
import core.planning.sase.sasToSat.translator.SaseTranslatorSettings;
import core.planning.sase.sasToSat.translator.SelectiveTranslator;
import core.satModelling.modelObjects.BasicSatFormula;
import core.satSolving.FormulaAnalyzer;

public class Translator {
    
    public enum TranslationMethod {
        direct, sase, isase, action, linear, reinforced, exist, disertDirect, compactDirect, compactReinforced, binaryReinforced, miniBin, selective;
    }

    public static void main(String[] args) {
        if (args.length < 3) {
            System.out.println("USAGE: java -jar translator.jar <problem.sas> <method> <makespan> [-m : multivalued sat output] [-a : add double actions]" +
            		"[-s : staticstics of formula");
            System.out.println("Methods: " + Arrays.toString(TranslationMethod.values()));
            return;
        }
        // input
        String problemName = args[0];
        TranslationMethod method = TranslationMethod.valueOf(args[1]);
        int makeSpan = Integer.parseInt(args[2]);
        boolean multiValued = contains(args, "-m");
        boolean doubleActions = contains(args, "-a");
        boolean statistics = contains(args, "-s");
        
        SasParser parser = new SasParser();
        SasProblem problem = null;

        try {
            problem = parser.parse(problemName);
            
            if (doubleActions) {
                DoubleActionCodec dac = new DoubleActionCodec();
                List<SasAction> actionsPairs = dac.makeActionPairs(problem.getOperators());
                problem.getOperators().addAll(actionsPairs);
            }
            
            problem.setActionIDs();
            if (!multiValued) {
                
                SasToSatTranslator translator = null;
                switch (method) {
                case isase:
                    translator = new SaseTranslator(problem);
                    break;
                case direct:
                    translator = new DirectTranslator(problem);
                    break;
                case sase:
                    SaseTranslatorSettings settings = new SaseTranslatorSettings();
                    settings.setUseOriginalGoalEncoding(true);
                    settings.setUseOriginalInitialStateEncoding(true);
                    translator = new SaseTranslator(problem, settings);
                    break;
                case action:
                    translator = new ActionOrientedTranslator(problem);
                    break;
                case linear:
                    translator = new DirectDoubleLinkedTranslator(problem);
                    break;
                case exist:
                    translator = new DirectExistStepTranslator(problem);
                    break;
                case reinforced:
                    translator = new ReinforcedSaseTranslator(problem);
                    break;
                case disertDirect:
                    translator = new DisertDirectTranslator(problem);
                    break;
                case compactDirect:
                    translator = new CompactDirect(problem);
                    break;
                case compactReinforced:
                    translator = new CompactReinforcedSaseTranslator(problem);
                    break;
                case binaryReinforced:
                    translator = new BinaryReinforcedSaseTranslator(problem);
                    break;
                case miniBin:
                    translator = new MiniBinTranslator(problem);
                    break;
                case selective:
                    translator = new SelectiveTranslator(problem);
                    break;
                }
                        
                BasicSatFormula formula = translator.makeFormulaForMakespan(makeSpan);
                if (statistics) {
                    String csv = FormulaAnalyzer.analyzeFormula(formula).csv();
                    System.out.println(problemName + ";" + csv);
                } else {
                    formula.printFormula(System.out);
                }
            } else {
                SasToMVSat translator = new SasToMVSat();
                MultiValuedCNF cnf = translator.translate(problem, makeSpan);
                cnf.printNoGoodFormat(System.out);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private static boolean contains(String[] list, String item) {
        for (String s : list) {
            if (s.equals(item)) {
                return true;
            }
        }
        return false;
    }

}
