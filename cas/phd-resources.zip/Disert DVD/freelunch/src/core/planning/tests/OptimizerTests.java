/*******************************************************************************
 * Copyright (c) 2012 Tomas Balyo and Vojtech Bardiovsky
 * 
 * This file is part of freeLunch
 * 
 * freeLunch is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation, either version 3 of the License, 
 * or (at your option) any later version.
 * 
 * freeLunch is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty 
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with freeLunch.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/
package core.planning.tests;

import java.io.IOException;
import java.util.List;

import junit.framework.TestCase;
import core.planning.NonexistentPlanException;
import core.planning.Solver;
import core.planning.TimeoutException;
import core.planning.benchmarking.BenchmarkProvider;
import core.planning.benchmarking.providers.SasFilesBenchmarkProvider;
import core.planning.forwardSearch.MemoryEfficientForwardSearchSolver;
import core.planning.model.Condition;
import core.planning.model.SasParallelPlan;
import core.planning.model.SasProblem;
import core.planning.sase.optimizer.ActionEliminationOptimizer;
import core.planning.sase.optimizer.PlanLoader;
import core.planning.sase.optimizer.PlanOptimizer;
import core.planning.sase.optimizer.PlanVerifier;
import core.planning.sase.optimizer.RedundancyEliminator;
import core.planning.sase.optimizer.model.PlanOptimizerParameters;
import core.planning.sase.optimizer.model.PlanOptimizerParameters.SelectionAlgorithm;
import core.planning.sase.optimizer.model.SubPlanStructure;
import core.planning.sase.sasToSat.SasParser;
import core.satSolving.maxsat.PartialMaxSatFormula;
import core.utilities.Stopwatch;

public class OptimizerTests extends TestCase {
    
    public void testMaxSatEncoding() throws IOException, TimeoutException, NonexistentPlanException {
        SasParser parser = new SasParser();
        SasProblem problem = parser.parse("testfiles/ipcbench/visitall-problem12.sas");
        Solver planner = new MemoryEfficientForwardSearchSolver(problem);
        SasParallelPlan plan = planner.solve();
        RedundancyEliminator elim = new RedundancyEliminator();
        PartialMaxSatFormula pmaxf = elim.encodeToPMaxSat(problem, plan);
        pmaxf.saveToDimacsFile("lol.wcnf");
    }
    
    public void testRedundancyEliminator() {
        Stopwatch optTime = new Stopwatch();
        optTime.pause();
        //BenchmarkProvider bp = new SasFilesBenchmarkProvider("testfiles/ipcbench", new String[] {"visitall", "elevators", "transport"});
        BenchmarkProvider bp = new SasFilesBenchmarkProvider("testfiles/ipcbench", new String[] {"visitall"});
        SasProblem problem = bp.getNext();
        ActionEliminationOptimizer optimizer1 = new ActionEliminationOptimizer();
        //RedundancyEliminator optimizer2 = new RedundancyEliminator();
        PlanVerifier verifier = new PlanVerifier();
        while (problem != null) {
            Solver planner = new MemoryEfficientForwardSearchSolver(problem);
            planner.getSettings().setTimelimit(20);
            try {
                SasParallelPlan plan  = planner.solve();
                if (verifier.verifyPlan(problem, plan) == false) {
                    System.out.println("invalid initial plan");
                }
                System.out.println(problem.getDescription());
                
                optTime.unpause();
                int oldPlan = plan.getPlanLength();
                optimizer1.optimizePlanFixPoint(problem, plan);
                //optimizer1.greedyOptimizePlanCost(problem, plan);
                int afterOpt1 = plan.getPlanLength();
                //optimizer2.optimizePlanIncremental(problem, plan);
                //optimizer2.optimizePlan(problem, plan);
                optTime.pause();
                
                if (verifier.verifyPlan(problem, plan) == false) {
                    System.out.println("invalid optimized plan");
                }
                int newPlan = plan.getPlanLength();
                System.out.println(String.format("%d -> %d -> %d (diff: %d,%d)", oldPlan, afterOpt1, newPlan, oldPlan - afterOpt1, afterOpt1 - newPlan));
            } catch (TimeoutException e) {
                // ignore
            } catch (NonexistentPlanException e) {
                // ignore
            }
            problem = bp.getNext();
        }
        System.out.println("time = " + optTime.elapsedFormatedSeconds());
    }
    
    
    public void testLightweightOptimizer() {
        BenchmarkProvider bp = new SasFilesBenchmarkProvider("testfiles/ipcbench", new String[] {"visitall", "elevators", "transport"});
        SasProblem problem = bp.getNext();
        ActionEliminationOptimizer optimizer = new ActionEliminationOptimizer();
        PlanVerifier verifier = new PlanVerifier();
        while (problem != null) {
            Solver planner = new MemoryEfficientForwardSearchSolver(problem);
            planner.getSettings().setTimelimit(20);
            try {
                SasParallelPlan plan  = planner.solve();
                if (verifier.verifyPlan(problem, plan) == false) {
                    System.out.println("invalid initial plan");
                }
                System.out.println(problem.getDescription());
                int oldPlan = plan.getPlanLength();
                optimizer.optimizePlan(problem, plan);
                if (verifier.verifyPlan(problem, plan) == false) {
                    System.out.println("invalid optimized plan");
                }
                int newPlan = plan.getPlanLength();
                System.out.println(String.format("%d -> %d (diff: %d)", oldPlan, newPlan, oldPlan - newPlan));
            } catch (TimeoutException e) {
                // ignore
            } catch (NonexistentPlanException e) {
                // ignore
            }
            problem = bp.getNext();
        }
    }
	
	public void testPlanLoader() throws IOException {
		SasParser parser = new SasParser();
		SasProblem problem = parser.parse("testfiles/output.sas");
		PlanLoader loader = new PlanLoader();
		SasParallelPlan plan = loader.loadPlanFromFile("testfiles/speedplan_1.SOL", problem);
		
		assertEquals(38, plan.getPlanLength());
		assertEquals(39, plan.getTotalActions());
		
		System.out.println(plan);
	}
	
	public void testPlanVerifier() throws IOException {
		SasParser parser = new SasParser();
		SasProblem problem = parser.parse("testfiles/output.sas");
		PlanLoader loader = new PlanLoader();
		SasParallelPlan plan = loader.loadPlanFromFile("testfiles/speedplan_1.SOL", problem);
		SasParallelPlan plan2 = loader.loadPlanFromFile("testfiles/optimal.sol", problem);
		PlanVerifier verifier = new PlanVerifier();
		boolean valid = verifier.verifyPlan(problem, plan);
		assertEquals(true, valid);
		valid = verifier.verifyPlan(problem, plan2);
		assertEquals(true, valid);
	}
	
	public void testSubPlan() throws IOException {
		SasParser parser = new SasParser();
		SasProblem problem = parser.parse("testfiles/output.sas");
		PlanLoader loader = new PlanLoader();
		SasParallelPlan plan = loader.loadPlanFromFile("testfiles/speedplan_1.SOL", problem);
		
		SubPlanStructure sps = new SubPlanStructure(plan, problem);
		
		List<Condition> x = sps.getInitialStateForTime(4);
		x = sps.getGoalStateForTime(4);
		System.out.println(x);
	}
	
	public void testPlanOptimizer() throws IOException {
		SasParser parser = new SasParser();
		SasProblem problem = parser.parse("testfiles/output.sas");
		PlanLoader loader = new PlanLoader();
		SasParallelPlan plan = loader.loadPlanFromFile("testfiles/speedplan_1.SOL", problem);
		PlanOptimizerParameters params = new PlanOptimizerParameters();
		//params.setVerbose(true);
		params.setWindowSelectionAlgorithm(SelectionAlgorithm.turbo);
		params.setTotalTimeLimit(20);
		//params.setIterations(30);
		//params.setWindowSize(12);
		params.setWindowShift(1);
		//params.setSolverTimeLimit(5);
		
		PlanOptimizer optimizer = new PlanOptimizer();
		optimizer.optimizePlan(problem, plan, params);
	}

}
