/*******************************************************************************
 * Copyright (c) 2013 Tomas Balyo and Vojtech Bardiovsky
 * 
 * This file is part of freeLunch
 * 
 * freeLunch is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation, either version 3 of the License, 
 * or (at your option) any later version.
 * 
 * freeLunch is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty 
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with freeLunch.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/
package core.planning.tests;

import java.io.IOException;

import core.planning.model.SasParallelPlan;
import core.planning.model.SasProblem;
import core.planning.sase.optimizer.PlanVerifier;
import core.planning.sase.sasToSat.SasParser;

import junit.framework.TestCase;


public class PlanLoaderTest extends TestCase {
    
    public void testLoader() throws IOException {
        String problemName = "C:\\Users\\tomas\\Desktop\\output.sas";
        SasParser parser = new SasParser();
        SasProblem problem = null;

        problem = parser.parse(problemName);
        
        SasParallelPlan plan = SasParallelPlan.loadFromFile("C:\\Users\\tomas\\Desktop\\output.soln", problem);
        
        PlanVerifier verif = new PlanVerifier();
        boolean ok = verif.verifyPlan(problem, plan);
        System.out.println(ok);
    }

}
