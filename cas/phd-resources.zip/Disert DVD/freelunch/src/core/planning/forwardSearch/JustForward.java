package core.planning.forwardSearch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import core.planning.AbstractSolver;
import core.planning.NonexistentPlanException;
import core.planning.Solver;
import core.planning.TimeoutException;
import core.planning.model.BasicSettings;
import core.planning.model.SasAction;
import core.planning.model.SasParallelPlan;
import core.planning.model.SasProblem;
import core.utilities.Stopwatch;

public class JustForward extends AbstractSolver implements Solver {

    protected final ForwardSearchSettings settings;

	public JustForward(SasProblem problem, ForwardSearchSettings settings) {
		super(problem);
		this.settings = settings;
	}

	@Override
	public SasParallelPlan solve() throws TimeoutException,	NonexistentPlanException {
		Stopwatch time = new Stopwatch();
		List<SasAction> plan = new ArrayList<SasAction>();
		int iterations = 0;
		
        int[] state = Arrays.copyOf(initialState, initialState.length);
        Set<SasAction> applicableActions = getApplicableActions(state);

        while (!isGoalState(state)) {
        	iterations++;
        	if (time.limitExceeded(settings.getTimelimit())) {
        		System.out.print(String.format(" iters = %d ", iterations));
        		throw new TimeoutException();
        	}
        	if (applicableActions.isEmpty()) {
        		// restart
        		plan.clear();
        		state = Arrays.copyOf(initialState, initialState.length);
        		applicableActions = getApplicableActions(state);
        	}
            SasAction best = settings.getHeuristic().select(state, new ArrayList<SasAction>(applicableActions));
            plan.add(best);
            int[] change = applyActionInPlace(best, state);
            updateApplicableActionsChanges(applicableActions, state, change);
        }
		
		List<List<SasAction>> pplan = new ArrayList<List<SasAction>>();
        for (SasAction op : plan) {
            List<SasAction> step = new ArrayList<SasAction>(1);
            step.add(op);
            pplan.add(step);
        }
		System.out.print(String.format(" iters = %d ", iterations));
        return new SasParallelPlan(pplan);
	}

	@Override
	public BasicSettings getSettings() {
		return settings;
	}

}
