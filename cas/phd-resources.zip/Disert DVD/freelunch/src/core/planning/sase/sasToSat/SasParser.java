/*******************************************************************************
 * Copyright (c) 2012 Tomas Balyo and Vojtech Bardiovsky
 * 
 * This file is part of freeLunch
 * 
 * freeLunch is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation, either version 3 of the License, 
 * or (at your option) any later version.
 * 
 * freeLunch is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty 
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with freeLunch.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/
package core.planning.sase.sasToSat;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import core.planning.model.Condition;
import core.planning.model.SasAction;
import core.planning.model.SasProblem;
import core.planning.model.StateVariable;
import core.planning.model.StringActionInfo;




public class SasParser {

    public SasParser() {
    }

    public SasProblem parse(String filename) throws IOException {
        FileReader fr = new FileReader(filename);
        BufferedReader reader = new BufferedReader(fr);
        SasProblem problem = new SasProblem();
        problem.setDescription(filename);
        String line = reader.readLine();
        List<StateVariable> stateVars = new ArrayList<StateVariable>();
        List<Condition> conditions = new ArrayList<Condition>();

        // read variables
        // ignore everything before variable definition
        while (!line.equals("end_metric")) {
            line = reader.readLine();
        }
        int vars = Integer.parseInt(reader.readLine());
        for (int i = 0; i < vars; i++) {
            line = reader.readLine();
            if(!line.equals("begin_variable")){
                throw new UnsupportedOperationException();
            }
            String varName = reader.readLine();
            if(!reader.readLine().equals("-1")){
                throw new UnsupportedOperationException("What is this??");
            }
            int domSize = Integer.parseInt(reader.readLine());
            StateVariable v = new StateVariable(varName, domSize);
            v.domainValues = new String[domSize];
            for(int j = 0; j < domSize; j++){
                v.domainValues[j] = reader.readLine();
            }
            line = reader.readLine();
            if(!line.equals("end_variable")){
                throw new UnsupportedOperationException();
            }
            stateVars.add(v);
        }
        problem.setVariables(new ArrayList<StateVariable>(stateVars));
        line = reader.readLine();
        
        // mutex groups
        List<List<Condition>> mutexGroups = new ArrayList<>();

        while (!line.equals("begin_state")) {
            if (line.equals("begin_mutex_group")) {
                List<Condition> mutexGroup = new ArrayList<>();
                line = reader.readLine();
                int mutexConds = Integer.parseInt(line);
                for (int i = 0; i < mutexConds; i++) {
                    line = reader.readLine();
                    mutexGroup.add(parseCondition(line, problem));
                }
                line = reader.readLine();
                assert line.equals("end_mutex_group");
                
                // test if the MUTEX group is trivial
                int varId = mutexGroup.get(0).getVariable().getId();
                boolean trivial = true;
                for (Condition c : mutexGroup) {
                    if (c.getVariable().getId() != varId) {
                        trivial = false;
                        break;
                    }
                }
                if (!trivial) {
                    mutexGroups.add(mutexGroup);
                }
            }
            line = reader.readLine();
        }
        problem.setMutexGroups(mutexGroups);

        // initial state
        for (int i = 0; i < vars; i++) {
            line = reader.readLine();
            int state = Integer.parseInt(line);
            conditions.add(new Condition(problem.getVariables().get(i), state));
        }
        problem.setInitialState(new ArrayList<Condition>(conditions));
        line = reader.readLine();
        assert line.equals("end_state");

        // goal state
        conditions.clear();
        while (!line.equals("begin_goal")) {
            line = reader.readLine();
        }
        int goals = Integer.parseInt(reader.readLine());
        for (int i = 0; i < goals; i++) {
            line = reader.readLine();
            conditions.add(parseCondition(line, problem));
        }
        problem.setGoal(new ArrayList<Condition>(conditions));
        line = reader.readLine();
        assert line.equals("end_goal");

        //operators
        List<SasAction> operatorList = new ArrayList<SasAction>();
        int operators = Integer.parseInt(reader.readLine());
        for (int i = 0; i < operators; i++) {
            line = reader.readLine();
            assert line.equals("begin_operator");
            line = reader.readLine();
            SasAction op = new SasAction(new StringActionInfo(line.trim()));
            line = reader.readLine();

            int prevailConds = Integer.parseInt(line);
            List<Condition> prevailConditions = new ArrayList<Condition>();
            for (int pc = 0; pc < prevailConds; pc++) {
                line = reader.readLine();
                prevailConditions.add(parseCondition(line, problem));
            }
            line = reader.readLine();

            int effects = Integer.parseInt(line);
            conditions.clear();
            List<Condition> effectList = new ArrayList<Condition>();
            for (int ef = 0; ef < effects; ef++) {
                line = reader.readLine().trim();
                String[] parts = line.split(" ");
                int effectConditions = Integer.parseInt(parts[0]);
                if (effectConditions > 0) {
                    throw new RuntimeException("The problem contains conditional effects. Conditional effects are not supported.");
                }
                int varId = Integer.parseInt(parts[parts.length-3]);
                StateVariable var = problem.getVariables().get(varId);
                int reqVal = Integer.parseInt(parts[parts.length-2]);
                int newVal = Integer.parseInt(parts[parts.length-1]);
                // -1 means no required value
                if (reqVal != -1) {
                    conditions.add(new Condition(var, reqVal));
                }
                effectList.add(new Condition(var, newVal));
            }
            op.setEffects(new ArrayList<Condition>(effectList));
            op.setPreconditions(new ArrayList<Condition>(conditions));
            op.getPreconditions().addAll(prevailConditions);
            line = reader.readLine();
            int cost = Integer.parseInt(line.trim());
            op.setCost(cost);
            line = reader.readLine();
            if (!line.equals("end_operator")) {
                throw new RuntimeException("SAS format error, 'end operator' expected");
            }
            operatorList.add(op);
        }
        problem.setOperators(new ArrayList<SasAction>(operatorList));
        return problem;
    }

    private Condition parseCondition(String line, SasProblem problem) {
        String[] parts = line.split(" ");
        int var = Integer.parseInt(parts[0]);
        int val = Integer.parseInt(parts[1]);
        return new Condition(problem.getVariables().get(var), val);
    }

}
