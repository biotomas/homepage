/*******************************************************************************
 * Copyright (c) 2012 Tomas Balyo and Vojtech Bardiovsky
 * 
 * This file is part of freeLunch
 * 
 * freeLunch is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation, either version 3 of the License, 
 * or (at your option) any later version.
 * 
 * freeLunch is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty 
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with freeLunch.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/
package core.satModelling.modelObjects;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class BasicSatFormula {
	
	private int variables;
	private List<int[]> clauses;
	
    /**
     * Parse a dimacs formula file into a basic formula
     * @param filename
     * @return the basic formula or null
     */
    public static BasicSatFormula parseFromFile(String filename) {
        List<int[]> clauseList = new ArrayList<int[]>();
    	BasicSatFormula formula = new BasicSatFormula(0, clauseList);
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(filename));
			String line = reader.readLine();
			while (line != null) {
	            if (line.startsWith("c")) {
					line = reader.readLine();
	                continue;
	            }
	            if (line.startsWith("p")) {
	                String[] tokens = line.split(" +");
	                formula.variables = Integer.parseInt(tokens[2]);
	                line = reader.readLine();
	                continue;
	            }
	            line = line.trim();
	            if (line.isEmpty()) {
	                line = reader.readLine();
	            	continue;
	            }
	            String[] lits = line.split(" +");
	            int litInClause = 0;
	            int clauseLength = lits.length - 1;
	            int[] literals = new int[clauseLength];
	            for (String slit : lits) {
	                if ("".equals(slit)) {
	                    continue;
	                }
	                int lit = Integer.parseInt(slit);
	                if (lit == 0) {
	                    break;
	                }
	                literals[litInClause] = lit;
	                litInClause++;
	            }
            	formula.clauses.add(literals);
				line = reader.readLine();
			}
	    	reader.close();
	    	return formula;
		} catch (IOException e) {
			try {
				reader.close();
			} catch (Exception e2) {
			}
			return null;
		}
    }
    
    public void printDimacsToFile(String filename) throws IOException {
        FileWriter out = new FileWriter(filename);
        out.write(String.format("p cnf %d %d\n", variables, clauses.size()));
        int varsize = 2 + (int) Math.log10(variables);
        for (int[] cl : clauses) {
            StringBuilder sb = new StringBuilder(varsize*cl.length + 3);
            for (int lit : cl) {
                sb.append(lit);
                sb.append(" ");
            }
            sb.append("0 \n");
            out.write(sb.toString());
        }
        out.close();
    }

	
	public BasicSatFormula(int variables, List<int[]> clauses) {
		this.variables = variables;
		this.clauses = clauses;
	}
	
	public int getVariables() {
		return variables;
	}
	
	public List<int[]> getClauses() {
		return clauses;
	}
	
	private String clauseToString(int[] lits) {
		StringBuilder sb = new StringBuilder();
		for (int l : lits) {
			sb.append(l);
			sb.append(" ");
		}
		sb.append("0");
		return sb.toString();
	}
	
	public void printClauses(PrintStream out) {
		for (int[] cl : clauses) {
			out.println(clauseToString(cl));
		}
	}
	
	public void printFormula(PrintStream out) {
	    out.println(String.format("p cnf %d %d\n", variables, clauses.size()));
	    printClauses(out);
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("p cnf %d %d\n", variables, clauses.size()));
		for (int[] cl : clauses) {
			sb.append(clauseToString(cl));
			sb.append("\n");
		}
		return sb.toString();
	}

}
