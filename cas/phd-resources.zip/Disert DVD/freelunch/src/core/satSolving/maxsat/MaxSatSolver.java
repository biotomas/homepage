package core.satSolving.maxsat;

public interface MaxSatSolver {
    
    public int[] solvePartialMaxsat(PartialMaxSatFormula pmax);

}
