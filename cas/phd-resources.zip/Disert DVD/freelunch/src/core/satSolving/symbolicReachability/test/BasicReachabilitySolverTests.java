/*******************************************************************************
 * Copyright (c) 2012 Tomas Balyo and Vojtech Bardiovsky
 * 
 * This file is part of freeLunch
 * 
 * freeLunch is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published 
 * by the Free Software Foundation, either version 3 of the License, 
 * or (at your option) any later version.
 * 
 * freeLunch is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty 
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with freeLunch.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/
package core.satSolving.symbolicReachability.test;

import java.util.ArrayList;

import core.planning.NonexistentPlanException;
import core.planning.Solver;
import core.planning.TimeoutException;
import core.planning.model.Condition;
import core.planning.model.SasAction;
import core.planning.model.SasParallelPlan;
import core.planning.model.SasProblem;
import core.planning.model.StateVariable;
import core.planning.model.StringActionInfo;
import core.planning.sase.optimizer.PlanVerifier;
import core.planning.sase.sasToSat.SasProblemBuilder;
import core.planning.sase.sasToSat.incremental.IncrementalSolver;
import core.planning.sase.sasToSat.symbolicReachability.SymbolicReachabilityProblemGenerator;
import core.satSolving.symbolicReachability.Sat4jReachSolver;
import core.satSolving.symbolicReachability.SymbolicReachVerifier;
import core.satSolving.symbolicReachability.SymbolicReachabilityProblem;
import core.satSolving.symbolicReachability.SymbolicReachabilitySolver;

import junit.framework.TestCase;

public class BasicReachabilitySolverTests extends TestCase {
    
    public void testGenerator() {
        SasProblem p = createProblem(5).getSasProblem();
        Solver s = new IncrementalSolver(p);
        try {
            SasParallelPlan plan = s.solve();
            System.out.println(plan);
        } catch (TimeoutException e) {
            e.printStackTrace();
        } catch (NonexistentPlanException e) {
            e.printStackTrace();
        }
    }

    public void testTrivialExample() {
        SasProblem p = createProblem(7).getSasProblem();
        SymbolicReachabilityProblemGenerator srpGen = new SymbolicReachabilityProblemGenerator(p);
        SymbolicReachabilityProblem prob = srpGen.getSRProblem();
        prob.print(System.out);
        System.out.println("---------");
        SymbolicReachabilitySolver solver = new Sat4jReachSolver(); //WalkieReachSolver();
        ArrayList<int[]> solution = solver.solve(prob);
        
        //malicious change to test the verifiers false negativeness
        //solution.get(2)[16] *= -1;
        
        SymbolicReachVerifier ver = new SymbolicReachVerifier();
        boolean valid = ver.solutionValid(prob, solution);
        System.out.println(valid);
        
        SasParallelPlan plan = srpGen.decodePlan(solution);
        System.out.println(plan);
        
        PlanVerifier verif = new PlanVerifier();
        boolean planOk = verif.verifyPlan(p, plan);
        System.out.println(planOk);
    }
    
    private SasProblemBuilder createProblem(int n) {
        SasProblemBuilder prob = new SasProblemBuilder();
        
        StateVariable var = prob.newVariable("x", n);
        
        prob.addInitialStateCondition(new Condition(var, 0));
        prob.addGoalCondition(new Condition(var, n-1));
        
        for (int i = 0; i+1 < n; i++) {
            SasAction a = prob.newAction(new StringActionInfo(String.format("%d->%d", i, i+1)));
            a.getPreconditions().add(new Condition(var, i));
            a.getEffects().add(new Condition(var, i+1));
        }
        
        return prob;
    }

    public void testLogisticsProblem() {
        /*
        SasProblem p = LogisticsProblemGenerator.generateProblem(3, 10, 5, 10).getSasProblem();
        p.initializeProblem();
        
        SymbolicReachabilityProblem prob = SymbolicReachabilityProblemGenerator.translate(p);
        SymbolicReachabilitySolver solver = new WalkieReachSolver();
        int[] result = solver.solve(prob);
        
        int makespan = result.length / prob.initialConditions.getVariables();
        
        SaseTranslator translator = new SaseTranslator(p);
        for (int i = 0; i < makespan; i++) {
            translator.setMaxTimespan(i);
        }
        SasParallelPlan plan = translator.decodePlan(result, makespan);
        PlanVerifier verifier = new PlanVerifier();
        boolean valid = verifier.verifyPlan(p, plan);
        System.out.println(plan.toString());
        if (valid) {
            System.out.println("Plan is VALID");
        } else {
            System.out.println("Plan is INVALID");
        }
        */
    }

}
