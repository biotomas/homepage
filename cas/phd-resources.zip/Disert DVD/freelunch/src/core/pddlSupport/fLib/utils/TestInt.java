/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package core.pddlSupport.fLib.utils;

/**
 *
 * @author FD
 */
public interface TestInt {
    boolean Test();
}
