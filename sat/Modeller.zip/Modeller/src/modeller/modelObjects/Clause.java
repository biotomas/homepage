package modeller.modelObjects;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import modeller.modelObjects.Variable.Literal;

/**
 * Class representing a Boolean clause.
 */
public class Clause {

    private List<Literal> literals;

    public Clause() {
        literals = new ArrayList<Literal>();
    }

    public Clause(Literal ... literals) {
        this.literals = Arrays.asList(literals);
    }

    public Clause(List<Literal> literals) {
        this.literals = literals;
    }

    public void addLiteral(Literal literal) {
        literals.add(literal);
    }

    public List<Literal> getLiterals() {
        return literals;
    }

    public int[] getLiteralsArray() {
        int[] res = new int[literals.size()];
        int i = 0;
        for (Literal l : literals) {
            res[i] = l.getIntRepresentation();
            i++;
        }
        return res;
    }

    public String toDimacs() {
        StringBuilder sb = new StringBuilder();
        for (Literal l : literals) {
            String var = Integer.toString(l.getVariable().getId());
            sb.append(l.isPositive() ? var : "-"+var);
            sb.append(" ");
        }
        sb.append("0");
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Literal l : literals) {
            sb.append(l.toString());
            sb.append(" ");
        }
        return sb.toString();
    }

}
