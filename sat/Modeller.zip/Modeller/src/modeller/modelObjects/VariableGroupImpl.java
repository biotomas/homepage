package modeller.modelObjects;

import modeller.interfaces.VariableGroup;

/**
 * @see modeller.interfaces.VariableGroup
 */
public class VariableGroupImpl implements VariableGroup {

    private String name;
    private Variable variable;
    private int dimensions;
    private boolean closed;

    public VariableGroupImpl(String name) {
        this.name = name;
        this.variable = new Variable(name);
        this.dimensions = 0;
        this.closed = false;
    }

    /*
     * @see modeller.interfaces.VariableGroup#getVariableOrArray(int[])
     */
    @Override
    public Variable getVariableOrArray(int ... indices) {
        Variable v = variable;
        for (int i : indices) {
            v = ((VariableArray)v).getVariable(i);
        }
        return v;
    }

    /*
     * @see modeller.interfaces.VariableGroup#addDimension(int, int)
     */
    @Override
    public VariableGroup addDimension(int lowerBound, int higherBound) {
        if (closed) {
            throw new RuntimeException("Adding dimension to a closed group " + name);
        }
        variable = addDimensionToVariable(variable, "", lowerBound, higherBound);
        dimensions++;
        return this;
    }

    private Variable addDimensionToVariable(Variable var, String suffix, int lowerBound, int higherBound) {
        if (var instanceof VariableArray) {
            VariableArray va = (VariableArray)var;
            int index = va.getLowerBound();
            for (int i = 0; i < va.getVariables().length; i++) {
                va.getVariables()[i] = addDimensionToVariable(va.getVariables()[i], suffix + "_" + Integer.toString(index), lowerBound, higherBound);
                index++;
            }
            return var;
        } else {
            return new VariableArray(name+suffix, lowerBound, higherBound);
        }
    }


    /*
     * @see modeller.interfaces.VariableGroup#closeGroup()
     */
    @Override
    public void closeGroup() {
        variable = closeGroup(variable, name);
        closed = true;
    }

    private Variable closeGroup(Variable var, String name) {
        if (var instanceof VariableArray) {
            VariableArray va = (VariableArray)var;
            int index = va.getLowerBound();
            for (int i = 0; i < va.getVariables().length; i++) {
                va.getVariables()[i] = closeGroup(va.getVariables()[i], va.getName() + "_" + Integer.toString(i+va.getLowerBound()));
                index++;
            }
            return var;
        } else {
            return new Variable(name);
        }
    }

    @Override
    public int getDimension() {
        return dimensions;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public Variable getVariableOrArray() {
        return variable;
    }




}
