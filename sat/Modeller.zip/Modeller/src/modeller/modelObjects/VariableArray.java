package modeller.modelObjects;



/**
 * Class representing an array of variables or array
 * of VariableArrays
 */
public class VariableArray extends Variable {

    private int lowerBound;
    private int higherBound;
    private Variable[] variables;
    private int offset;

    public VariableArray(String name, int lowerBound, int higherBound) {
        super(name);
        this.lowerBound = lowerBound;
        this.higherBound = higherBound;
        offset = lowerBound;
        variables = new Variable[higherBound - lowerBound];
    }

    public void setVariable(Variable variable, int index) {
        variables[index - offset] = variable;
    }

    public Variable getVariable(int index) {
        return variables[index - offset];
    }

    @Override
    public int getId() {
        throw new RuntimeException("Invalid operation for variable arrays");
    }

    public Variable[] getVariables() {
        return variables;
    }

    /**
     * @return the lowerBound
     */
    public int getLowerBound() {
        return lowerBound;
    }

    /**
     * @return the higherBound
     */
    public int getHigherBound() {
        return higherBound;
    }

}
