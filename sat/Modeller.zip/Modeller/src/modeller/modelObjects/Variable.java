package modeller.modelObjects;

/**
 * Class representing a Boolean variable
 */
public class Variable {

    public class Literal {

        private Variable variable;
        private boolean positive;

        private Literal(Variable variable, boolean positive) {
            this.variable = variable;
            this.positive = positive;
        }

        public boolean isPositive() {
            return positive;
        }

        public Variable getVariable() {
            return variable;
        }

        public int getIntRepresentation() {
            return positive ? variable.getId() : -variable.getId();
        }

        @Override
        public String toString() {
            String var = variable.toString();
            return positive ? var : "-" + var;
        }
    }

    private String name;
    private int id;
    private Literal positiveLit;
    private Literal negativeLit;

    public Variable(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Literal getPositive() {
        if (positiveLit == null) {
            positiveLit = new Literal(this, true);
        }
        return positiveLit;
    }

    public Literal getNegative() {
        if (negativeLit == null) {
            negativeLit = new Literal(this, false);
        }
        return negativeLit;
    }

    @Override
    public String toString() {
        return name;
    }
}
