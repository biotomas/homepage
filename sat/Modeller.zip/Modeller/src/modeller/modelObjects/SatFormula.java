package modeller.modelObjects;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Boolean satisfiability formula
 * in the conjunctive normal form
 */
public class SatFormula {

    private List<Clause> clauses;
    private int varsCount;

    public SatFormula(int varsCount, List<Clause> clauses) {
        this.varsCount = varsCount;
        this.clauses = clauses;
    }

    public int getVariablesCount() {
        return varsCount;
    }

    public int getClausesCount() {
        return clauses.size();
    }

    public List<Clause> getClauses() {
        return clauses;
    }

    public List<String> getDimacsRepresentation() {
        List<String> fla = new ArrayList<String>(getClausesCount()+1);
        fla.add(String.format("p cnf %d %d", varsCount, getClausesCount()));
        for (Clause c : clauses) {
            fla.add(c.toDimacs());
        }
        return fla;
    }

}
