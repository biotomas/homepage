package modeller.effectiveVariableGroup;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class IntVarGroupManager {

    public class IntVarGroup {

        /**
         * This recursive structure represents an array of
         * variables or an array of VariableVectors.
         */
        private class VariableVector {
            // only one of the arrays should be initialized
            private VariableVector[] subVectors = null;
            private int[] variables = null;
        }

        private int dimensions;
        private int[] dimensionSizes;
        /**
         * Indicates if the variable IDs need to be recomputed
         */
        private boolean dirty;
        private VariableVector variableVector;

        private IntVarGroup(int dimensions) {
            this.dimensions = dimensions;
            this.dimensionSizes = new int[dimensions];
            dirty = true;
        }

        public void setDimensionSize(int dimension, int newRange) {
            if (dimensionSizes[dimension] >= newRange) {
                return;
            }
            dimensionSizes[dimension] = newRange;
            dirty = true;
        }

        public int getVariable(int ... coordinates) {
            if (dirty) {
                recomputeIds();
            }
            VariableVector v = variableVector;
            int len = coordinates.length - 1;
            for (int i = 0; i < len; i++) {
                v = v.subVectors[coordinates[i]];
            }
            return v.variables[coordinates[len]];
        }

        private void recomputeIds() {
            variableVector = fixVariableVector(variableVector, 0);
            dirty = false;
        }

        private VariableVector fixVariableVector(VariableVector vec, int dimension) {
            if (vec == null) {
                vec = new VariableVector();
            }
            int dimensionSize = dimensionSizes[dimension];
            // variable vector
            if (dimension+1 < dimensions) {
                // if allocation needed
                if (vec.subVectors == null) {
                    vec.subVectors = new VariableVector[dimensionSize];
                }
                // if reallocation needed
                if (vec.subVectors.length < dimensionSize) {
                    vec.subVectors = Arrays.copyOf(vec.subVectors, dimensionSize);
                }
                // update subvectors
                for (int i = 0; i < dimensionSize; i++) {
                    vec.subVectors[i] = fixVariableVector(vec.subVectors[i], dimension + 1);
                }
            } else {
                // if allocation needed
                if (vec.variables == null) {
                    vec.variables = new int[dimensionSize];
                    Arrays.fill(vec.variables, 0);
                }
                // if reallocation needed
                if (vec.variables.length < dimensionSize) {
                    vec.variables = Arrays.copyOf(vec.variables, dimensionSize);
                }
                // add IDs if needed
                for (int i = 0; i < dimensionSize; i++) {
                    if (vec.variables[i] == 0) {
                        lastUsedId++;
                        vec.variables[i] = lastUsedId;
                    }
                }
            }
            return vec;
        }
    }

    private List<IntVarGroup> varGroups;
    private int lastUsedId;

    public IntVarGroupManager() {
        varGroups = new ArrayList<IntVarGroup>();
        lastUsedId = 0;
    }

    public IntVarGroup createNewVarGroup(int dimensions) {
        IntVarGroup ng = new IntVarGroup(dimensions);
        varGroups.add(ng);
        return ng;
    }

    public int getTotalVarsCount() {
        for (IntVarGroup vg : varGroups) {
            if (vg.dirty) {
                vg.recomputeIds();
            }
        }
        return lastUsedId;
    }

}
