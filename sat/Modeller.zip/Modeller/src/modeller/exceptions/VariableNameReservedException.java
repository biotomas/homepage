package modeller.exceptions;

public class VariableNameReservedException extends RuntimeException {

    private static final long serialVersionUID = 2125471443622569100L;
    private String name;

    public VariableNameReservedException(String name) {
        this.name = name;
    }

    @Override
    public String getMessage() {
        return String.format("Variable name %s is already used", name);
    }

}
