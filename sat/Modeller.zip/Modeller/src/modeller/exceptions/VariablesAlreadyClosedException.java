package modeller.exceptions;

public class VariablesAlreadyClosedException extends RuntimeException {

    private static final long serialVersionUID = 5346545930195984908L;

}
