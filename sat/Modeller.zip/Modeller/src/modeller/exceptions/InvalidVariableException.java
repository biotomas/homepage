package modeller.exceptions;

public class InvalidVariableException extends RuntimeException {

    private static final long serialVersionUID = 1L;

}
