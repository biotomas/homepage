package modeller.basicModellers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modeller.exceptions.InvalidVariableException;
import modeller.exceptions.VariableNameReservedException;
import modeller.interfaces.BasicModeller;
import modeller.modelObjects.Clause;
import modeller.modelObjects.SatFormula;
import modeller.modelObjects.Variable;
import modeller.modelObjects.Variable.Literal;

public class TrivialBasicModeller implements BasicModeller {

    Map<String, Variable> vars;
    List<Clause> clauses;

    public TrivialBasicModeller() {
        vars = new HashMap<String, Variable>();
        clauses = new ArrayList<Clause>();
    }

    @Override
    public void addClause(Clause clause) throws InvalidVariableException {
        for (Literal l : clause.getLiterals()) {
            if (!vars.containsKey(l.getVariable())) {
                throw new InvalidVariableException();
            }
        }
        clauses.add(clause);
    }

    @Override
    public void addClause(List<Literal> literals) throws InvalidVariableException {
        Clause clause = new Clause(literals);
        addClause(clause);
    }

    @Override
    public Variable createVariable(String name) throws VariableNameReservedException {
        if (vars.containsKey(name)) {
            throw new VariableNameReservedException(name);
        }
        Variable var = new Variable(name);
        vars.put(name, var);
        return var;
    }

    @Override
    public SatFormula getSatFormula() {
        setVariableIds();
        return new SatFormula(vars.size(), clauses);
    }

    private void setVariableIds() {
        int i = 1;
        for (Variable v : vars.values()) {
            v.setId(i);
            i++;
        }
    }

    @Override
    public String toString() {
        return vars + "\n" + clauses.toString();
    }

}
