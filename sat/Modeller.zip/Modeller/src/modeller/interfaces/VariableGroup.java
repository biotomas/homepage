package modeller.interfaces;

import modeller.modelObjects.Variable;

/**
 * Represents a group of variables which have the same
 * name and differ by indices
 * @author user
 *
 */
public interface VariableGroup {

    /**
     * Returns the variable specified by the indices. If not
     * all indices are specified a range of variables is
     * returned.
     * @param indices
     * @return
     */
    public Variable getVariableOrArray(int... indices);

    /**
     * Returns the core variable range
     * @return
     */
    public Variable getVariableOrArray();

    /**
     * Add dimension to the variable group. After the last addDimension
     * closeGroup() must be called
     * @param lowerBound
     * @param higherBound
     * @return
     */
    public VariableGroup addDimension(int lowerBound, int higherBound);

    /**
     * Call this method after you finished adding dimensions
     * but before the first usage of the group
     */
    public void closeGroup();

    /**
     * @return the dimension of this group
     */
    public int getDimension();

    /**
     * @return the name of this group
     */
    public String getName();

}
