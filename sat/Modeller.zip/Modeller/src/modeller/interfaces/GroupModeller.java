package modeller.interfaces;

import java.util.Collection;

import modeller.exceptions.VariableNameReservedException;
import modeller.modelObjects.Variable;
import modeller.modelObjects.VariableArray;

/**
 * SAT modeling interface with support of groups of variables
 */
public interface GroupModeller extends BasicModeller {

    /**
     * Create a group of variables with the given name.
     * The name must be unique.
     * @param name
     * @return
     * @throws VariableNameReservedException
     */
    public VariableGroup createVariableGroup(String name) throws VariableNameReservedException;

    /**
     * Call this method after you finish adding variables. After
     * this method has been called, no variables can be added.
     */
    public void closeVariables();

    /**
     * Adds such clauses that enforce that only one of the
     * variables can be true
     * @param varGroup
     */
    public void addAtMostOneConstraint(VariableArray varGroup);

    /**
     * Adds such clauses that enforce that only one of the
     * variables can be true
     * @param variables
     */
    public void addAtMostOneConstraint(Collection<Variable> variables);

    /**
     * Adds a clause, that will enforce that at least of
     * the specified variables will be true
     * @param varGroup
     */
    public void addAtLeastOneConstraint(VariableArray varGroup);

    /**
     * Adds a clause, that will enforce that at least of
     * the specified variables will be true
     * @param variables
     */
    public void addAtLeastOneConstraint(Collection<Variable> variables);

}
