package modeller.interfaces;

import java.util.List;

import modeller.exceptions.InvalidVariableException;
import modeller.exceptions.VariableNameReservedException;
import modeller.modelObjects.Clause;
import modeller.modelObjects.SatFormula;
import modeller.modelObjects.Variable;
import modeller.modelObjects.Variable.Literal;

/**
 * Basic SAT modeling interface. Contains only basic functionality of
 * adding variables and clauses.
 */
public interface BasicModeller {

    /**
     * Registers a new variable in the formula with the
     * given name. Throws an {@link VariableNameReservedException} if the
     * name is already used
     * @param name variable name
     * @return variable object
     * @throws VariableNameReservedException
     */
    public Variable createVariable(String name) throws VariableNameReservedException;

    /**
     * Adds a new clause to the formula. Throws an {@link InvalidVariableException} if
     * the literals of the clause are not registered variables.
     * @param clause a clause to add
     * @throws InvalidVariableException
     */
    public void addClause(Clause clause) throws InvalidVariableException;

    /**
     * Adds a new clause to the formula specified by the list
     * of its literals. Throws an {@link InvalidVariableException} if the literals
     * are not registered variables.
     * @param literals literals to add
     * @throws InvalidVariableException
     */
    public void addClause(List<Literal> literals) throws InvalidVariableException;

    /**
     * Generate the resulting SAT formula
     * @return resulting formula
     */
    public SatFormula getSatFormula();

}
