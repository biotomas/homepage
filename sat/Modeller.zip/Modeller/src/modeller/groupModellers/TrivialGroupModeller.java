package modeller.groupModellers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modeller.exceptions.VariableNameReservedException;
import modeller.exceptions.VariablesAlreadyClosedException;
import modeller.interfaces.GroupModeller;
import modeller.interfaces.VariableGroup;
import modeller.modelObjects.Clause;
import modeller.modelObjects.SatFormula;
import modeller.modelObjects.Variable;
import modeller.modelObjects.VariableArray;
import modeller.modelObjects.VariableGroupImpl;
import modeller.modelObjects.Variable.Literal;

public class TrivialGroupModeller implements GroupModeller {

    private Map<String, VariableGroup> varGroups;
    private Map<String, Variable> vars;
    private List<Clause> clauses;
    private boolean varsClosed;
    private int varsCount;

    public TrivialGroupModeller() {
        varGroups = new HashMap<String, VariableGroup>();
        vars = new HashMap<String, Variable>();
        clauses = new ArrayList<Clause>();
        varsClosed = false;
    }

    @Override
    public void addAtLeastOneConstraint(Collection<Variable> variables) {
        if (variables.size() == 0) {
            return;
        }
        Clause c = new Clause();
        for (Variable v : variables) {
            c.addLiteral(v.getPositive());
        }
        clauses.add(c);
    }

    @Override
    public void addAtLeastOneConstraint(VariableArray varGroup){
        addAtLeastOneConstraint(getVarsFromGroup(varGroup));
    }

    @Override
    public void addAtMostOneConstraint(Collection<Variable> variables) {
        if (variables.size() == 0) {
            return;
        }
        // for each possible pair x,y add (-x,-y)
        if (!(variables instanceof ArrayList<?>)) {
            variables = new ArrayList<Variable>(variables);
        }
        ArrayList<Variable> vars = (ArrayList<Variable>) variables;
        for (int i = 0; i+1 < vars.size(); i++) {
            for (int j = i+1; j < vars.size(); j++) {
                Clause c = new Clause(vars.get(i).getNegative(), vars.get(j).getNegative());
                clauses.add(c);
            }
        }
    }

    @Override
    public void addAtMostOneConstraint(VariableArray varGroup) {
        addAtMostOneConstraint(getVarsFromGroup(varGroup));
    }

    private List<Variable> getVarsFromGroup(VariableArray varGroup) {
        List<Variable> vars = new ArrayList<Variable>();
        collectVariables(vars, varGroup);
        return vars;
    }

    private void collectVariables(List<Variable> vars, Variable var) {
        if (var instanceof VariableArray) {
            VariableArray va = (VariableArray) var;
            for (Variable v : va.getVariables()) {
                collectVariables(vars, v);
            }
        } else {
            vars.add(var);
        }
    }

    @Override
    public VariableGroup createVariableGroup(String name) {
        if (varsClosed) {
            throw new VariablesAlreadyClosedException();
        }
        if (varGroups.containsKey(name)) {
            throw new VariableNameReservedException(name);
        }
        VariableGroup vg = new VariableGroupImpl(name);
        varGroups.put(name, vg);
        return vg;
    }

    @Override
    public void addClause(Clause clause) {
        clauses.add(clause);
    }

    @Override
    public void addClause(List<Literal> literals) {
        if (literals.size() == 0) {
            return;
        }
        Clause cl = new Clause(literals);
        addClause(cl);
    }

    @Override
    public Variable createVariable(String name) {
        if (varsClosed) {
            throw new VariablesAlreadyClosedException();
        }
        if (vars.containsKey(name)) {
            throw new VariableNameReservedException(name);
        }
        Variable v = new Variable(name);
        vars.put(name, v);
        return v;
    }

    @Override
    public void closeVariables() {
        if (varsClosed) {
            return;
        }
        varsCount = setVariableIds();
        varsClosed = true;
    }

    @Override
    public SatFormula getSatFormula() {
        closeVariables();
        return new SatFormula(varsCount, clauses);
    }

    /**
     * Set the IDs of the variables and return
     * the total number of variables
     * @return
     */
    private int setVariableIds() {
        int current = 1;
        // simple variables first
        for (Variable v : vars.values()) {
            v.setId(current);
            current++;
        }
        // variable groups
        for (VariableGroup vg : varGroups.values()) {
            Variable var = vg.getVariableOrArray();
            current = setVarArrayIds(var, current);
        }
        return current - 1;
    }

    /**
     * Set the IDs of variables in variable arrays
     * @param var a variable or a variable array
     * @param start IDs start from this number
     * @return the next available ID
     */
    private int setVarArrayIds(Variable var, int start) {
        if (var instanceof VariableArray) {
            VariableArray va = (VariableArray) var;
            for (Variable v : va.getVariables()) {
                start = setVarArrayIds(v, start);
            }
        } else {
            var.setId(start);
            start++;
        }
        return start;
    }
}
