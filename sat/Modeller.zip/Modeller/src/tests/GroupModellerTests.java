package tests;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;
import modeller.exceptions.InvalidVariableException;
import modeller.exceptions.VariableNameReservedException;
import modeller.groupModellers.TrivialGroupModeller;
import modeller.interfaces.GroupModeller;
import modeller.interfaces.VariableGroup;
import modeller.modelObjects.Variable;
import modeller.modelObjects.VariableArray;
import modeller.modelObjects.VariableGroupImpl;

public class GroupModellerTests extends TestCase {

    public void testVariableGroup() {
        VariableGroup vg = new VariableGroupImpl("sudoku");
        vg.addDimension(1, 9);
        vg.addDimension(1, 9);
        vg.addDimension(1, 9);
        vg.closeGroup();
        System.out.println(vg.getVariableOrArray(5,4,2).toString());
        System.out.println(vg.getVariableOrArray(5,4,2).toString());
        System.out.println(vg.getVariableOrArray(5,4,2).toString());
    }

    public void testGroupModellerPigeon() throws VariableNameReservedException, InvalidVariableException {
        GroupModeller gm = new TrivialGroupModeller();
        VariableGroup vg = gm.createVariableGroup("inHole");
        int problemSize = 5;
        // which pigeon
        vg.addDimension(1, problemSize + 1);
        // in which hole
        vg.addDimension(1, problemSize);
        vg.closeGroup();

        //each pigeon somewhere
        for (int p = 1; p <= problemSize; p++) {
            gm.addAtLeastOneConstraint((VariableArray) vg.getVariableOrArray(p));
        }
        //at most one pigeon for each hole
        for (int h = 1; h < problemSize; h++) {
            List<Variable> vars = new ArrayList<Variable>(problemSize);
            for (int p = 1; p <= problemSize; p++) {
                vars.add(vg.getVariableOrArray(p,h));
            }
            gm.addAtMostOneConstraint(vars);
        }
        List<String> fla = gm.getSatFormula().getDimacsRepresentation();
        for (String s : fla) {
            System.out.println(s);
        }
    }

}
